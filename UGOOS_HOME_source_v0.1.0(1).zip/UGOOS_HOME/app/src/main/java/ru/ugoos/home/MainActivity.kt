package ru.ugoos.home

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 27, 48)
    private val panel = Color.rgb(29, 48, 75)
    private val accent = Color.rgb(67, 155, 255)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildHome()
    }

    private fun buildHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 28, 48, 24)
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(label("UGOOS", 30, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label(SimpleDateFormat("HH:mm  •  dd MMMM", Locale("ru")).format(Date()), 22, Color.LTGRAY, false))
        root.addView(header)

        val greeting = label("Добрый вечер!\nПриятного просмотра", 27, Color.WHITE, true)
        greeting.setPadding(0, 34, 0, 24)
        root.addView(greeting)

        val tiles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        tiles.addView(tile("▶\nYouTube", accent) { launchByName("YouTube") },
            LinearLayout.LayoutParams(0, 190, 1.2f).apply { rightMargin = 18 })
        tiles.addView(tile("+\nДобавить приложение", panel) { chooseApp() },
            LinearLayout.LayoutParams(0, 190, 1f))
        root.addView(tiles)

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }
        listOf("Все приложения", "Кино", "IPTV", "Музыка", "Браузер", "Настройки").forEach { name ->
            val v = label(name, 17, Color.LTGRAY, false).apply {
                gravity = Gravity.CENTER
                setPadding(12, 18, 12, 18)
                isFocusable = true
                isFocusableInTouchMode = true
                setOnClickListener { if (name == "Все приложения") chooseApp() else if (name == "Настройки") openSettings() else chooseApp() }
                setOnFocusChangeListener { view, focused -> view.setBackgroundColor(if (focused) accent else Color.TRANSPARENT) }
            }
            dock.addView(v, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(dock)
        val footer = label("◀ ▲ ▼ ▶  Навигация       OK  Выбрать       BACK  Назад", 14, Color.GRAY, false)
        footer.gravity = Gravity.CENTER
        footer.setPadding(0, 20, 0, 0)
        root.addView(footer)
        setContentView(root)
        root.post { root.findFocus() ?: root.getChildAt(2).requestFocus() }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun tile(text: String, color: Int, action: () -> Unit) =
        TextView(this).apply {
            this.text = text
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            setBackgroundColor(color)
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { action() }
            setOnFocusChangeListener { view, focused ->
                view.setBackgroundColor(if (focused) accent else color)
                view.scaleX = if (focused) 1.025f else 1f
                view.scaleY = if (focused) 1.025f else 1f
            }
        }

    private fun launchByName(part: String) {
        val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        val match = apps.firstOrNull { packageManager.getApplicationLabel(it).toString().contains(part, true) }
        if (match != null) packageManager.getLaunchIntentForPackage(match.packageName)?.let { startActivity(it) }
        else chooseApp()
    }

    private fun chooseApp() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0).sortedBy { it.loadLabel(pm).toString().lowercase() }
        val names = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Выберите приложение").setItems(names) { _, which ->
            val item = apps[which]
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(item.activityInfo.packageName, item.activityInfo.name))
        }.setNegativeButton("Закрыть", null).show()
    }

    private fun openSettings() {
        try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
        catch (_: Exception) { chooseApp() }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) { buildHome(); return true }
        return super.onKeyDown(keyCode, event)
    }
}
